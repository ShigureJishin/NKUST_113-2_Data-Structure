#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#define DEBUG (0)

char temp1[1000],temp2[1000],temp3[1000];
int temp,temp4,temp5;

typedef struct{
	int id;
	char name[1000];
	char address[1000];
	char date[1000];
}store;
store student[1000];

typedef struct{
	int idd;
	char namee[1000];
	char time[1000];
	char scores[1000];
}sto;
sto clas[1000];


typedef struct{
	int idstu;
	int idcla;
	int score;
}st;
st grade[1000];

int id_cou=0,id_cou2=0,id_cou3=0;
int main (){
	for (int i =0;i<1000;i++){
		clas[i].idd=-1;
		student[i].id=-1;
	}
	
	while (1){
		char n[1000];
		int i,j;
		scanf("%s",&n);
		//printf("%c\n",n);
				
		int cou=0;
		//�s�W�ǥ͸��
		if(strcmp(n,"addstudent") == 0 ){
		
			scanf("%d %s %s %s",&temp,&temp1,&temp2,&temp3);
			//printf("test %d %s %s %s\n",temp,temp1,temp2,temp3);
			for(i=0;i<id_cou;i++){
				if (temp == student[i].id){
					cou=1;
				}
			}
			
				
			if (cou==1){
				printf("Duplicated\n");
				continue;
			}
			
			if(cou!=1){
				
				student[id_cou].id=temp;
				
				strcpy(student[id_cou].name, temp1);
				strcpy(student[id_cou].address, temp2);
				strcpy(student[id_cou].date, temp3);
					
				
				
				if DEBUG{
					printf("test %d %s %s %s\n",student[id_cou].id,student[id_cou].name,student[id_cou].address,student[id_cou].date);
					//printf("test2 %d %s %s %s\n",clas[id_cou].idd,clas[id_cou].namee,clas[id_cou].time,clas[id_cou].scores);
				}
				
				id_cou++;
			}
		}
		//�s�W�ҵ{���
		if(strcmp(n,"addcourse") == 0 ){
			cou=0;
			scanf("%d %s %s %s",&temp,&temp1,&temp2,&temp3);
			//printf("test %d %s %s %s\n",temp,temp1,temp2,temp3);
			for(i=0;i<id_cou2;i++){
				if (  temp == clas[i].idd ){
					cou=1;
				}
			}
			
				
			if (cou==1){
				printf("Duplicated\n");
				continue;
			}
			
			if(cou!=1){
				clas[id_cou2].idd=temp;
				
				strcpy(clas[id_cou2].namee, temp1);
				strcpy(clas[id_cou2].time, temp2);
				strcpy(clas[id_cou2].scores, temp3);
					
				
				
				if DEBUG{
					printf("test2 %d %s %s %s\n",clas[id_cou2].idd,clas[id_cou2].namee,clas[id_cou2].time,clas[id_cou2].scores);
				}
				id_cou2++;
			}
		}
		
		
		int cou2=0,cou3=0;
		//�s�W�ǥ����p�ҵ{���Z���
		if(strcmp(n,"addgrade") == 0 ){
		
			scanf("%d %d %d",&temp,&temp4,&temp5);
			//printf("test %d %s %s %s\n",temp,temp1,temp2,temp3);
			for(i=0;i<id_cou3;i++){
				if (  (temp == grade[i].idcla) && (temp4 == grade[i].idstu) ){
					cou=1;
				}
				
			}
			
				
			if (cou==1 ){
				printf("Duplicated\n");
				continue;
			}
			
			if(cou!=1){
				grade[id_cou3].idcla=temp;
				grade[id_cou3].idstu=temp4;
				grade[id_cou3].score=temp5;

				if DEBUG{
					printf("test3 %d %d %d\n",grade[id_cou3].idcla,grade[id_cou3].idstu,grade[id_cou3].score);
				}
				id_cou3++;
			}
		
		}

		if(strcmp(n,"showstudinfo") == 0 ){
			for ( i = 0; i < id_cou; i++) {
				for ( j = i; j < id_cou; j++) {
					if(student[i].id>student[j].id){
						temp=student[i].id;
						student[i].id=student[j].id;
						student[j].id=temp;
						
						strcpy(temp1, student[i].name);
						strcpy(student[i].name, student[j].name);
						strcpy(student[j].name, temp1);
						
						strcpy(temp1, student[i].address);
						strcpy(student[i].address, student[j].address);
						strcpy(student[j].address, temp1);
						
						strcpy(temp1, student[i].date);
						strcpy(student[i].date, student[j].date);
						strcpy(student[j].date, temp1);
					}
					
					
				}
			}
			for (i=0;i<id_cou;i++){
				printf("%d %s %s %s\n",student[i].id,student[i].name,student[i].address,student[i].date);
			}	
		}
		//��ܽҵ{���
		if(strcmp(n,"showcourseinfo") == 0 ){
			for ( i = 0; i < id_cou; i++) {
				for ( j = i; j < id_cou; j++) {
					if(clas[i].idd>clas[j].idd){
						temp=clas[i].idd;
						clas[i].idd=clas[j].idd;
						clas[j].idd=temp;
						
						strcpy(temp1, clas[i].namee);
						strcpy(clas[i].namee, clas[j].namee);
						strcpy(clas[j].namee, temp1);
						
						strcpy(temp1, clas[i].scores);
						strcpy(clas[i].scores, clas[j].scores);
						strcpy(clas[j].scores, temp1);
						
						strcpy(temp1, clas[i].time);
						strcpy(clas[i].time, clas[j].time);
						strcpy(clas[j].time, temp1);
					}
					
					
				}
			}
			for (i=0;i<id_cou;i++){
				printf("%d %s %s %s\n",clas[i].idd,clas[i].namee,clas[i].time,clas[i].scores);
			}	
		}

		
		//��ܽҵ{���Z
		if(strcmp(n,"showcoursegrade") == 0 ){
			
			int temp[1000],t=0, tmp, courseID=0;
			scanf("%d", &courseID);
			for (int i = 0; i < id_cou3; i++) {
				if (grade[i].idcla == courseID) {
					temp[t] = i;
					t++;
				}
			}
			for (int i = 0; i < t; i++) {
				for (int j = 0; j < t; j++) {
					if (grade[temp[i]].score > grade[temp[j]].score) {
						tmp = temp[i];
						temp[i] = temp[j];
						temp[j] = tmp;
					}
				}
			}
			for (int i = 0; i < t; i++) {
				for (int j = 0; j < t; j++) {
					if (grade[temp[i]].score == grade[temp[j]].score) {
						if (grade[temp[i]].idstu< grade[temp[j]].idstu) {
							tmp = temp[i];
							temp[i] = temp[j];
							temp[j] = tmp;
						}
					}
					
				}
			}
			
			for (int i = 0; i < t; i++) {
				for (int j = 0; j <=id_cou2+1 ; j++) {
					if (clas[j].idd == grade[temp[i]].idcla) {
						printf("%s ",clas[j].namee );
						break;
					}
				}
				for (int j = 0; j < id_cou; j++) {
					if (student[j].id == grade[temp[i]].idstu) {
						printf("%s %s %d\n", student[j].name, student[j].address, grade[temp[i]].score);
						break;
					}
				}
			}
		}
		
		//��ܾǥͦW���ƦW		
		if (strcmp(n, "ranking") == 0) {
			int t[1000];//�C��ǥͦU���X��
			int temp[1000];
			double tmp;
			double Fraction_total[1000];//�C��ǥ��`��
			double average[1000];//�C��ǥͥ���
			for (int i = 0; i < 1000; i++) {
				temp[i]=i;
				Fraction_total[i] = 0;
				t[i] = 0;
			}

			for (int i = 0; i < id_cou3; i++) {
				for (int j = 0; j < id_cou; j++) {
					if (student[j].id == grade[i].idstu) {
						Fraction_total[j] = Fraction_total[j] + grade[i].score;
						t[j]++;
					}
				}
			}
			for (int i = 0; i < id_cou; i++) {
				average[i] = Fraction_total[i] / t[i];
			}
			
			for (int i = 0; i < id_cou; i++) {
				for (int j = 0; j < id_cou; j++) {
					if (average[temp[i]] > average[temp[j]]) {
						tmp = temp[i];
						temp[i] = temp[j];
						temp[j] = tmp;
					}
				}
			}
			for (int i = 0; i < id_cou; i++) {
				for (int j = 0; j < id_cou; j++) {
					if (average[temp[i]] == average[temp[j]]) {
						
						if (student[temp[i]].id < student[temp[j]].id) {
							
							tmp = temp[i];
							temp[i] = temp[j];
							temp[j] = tmp;
						}
					}
				}
			}
			for (int i = 0; i < id_cou; i++) {
				printf("%s\n", student[temp[i]].name);
			}
		}
		//���}
		if (strcmp(n, "exit") == 0) {
			break;
		}

		
		
		 
	}
	system("Pause");
	return 0;
	
}
